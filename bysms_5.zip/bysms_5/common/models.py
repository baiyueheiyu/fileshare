from django.db import models

class Customer(models.Model):
    # 客户名称
    name = models.CharField(max_length=200)

    # 联系电话
    phonenumber = models.CharField(max_length=200)

    # 地址
    address = models.CharField(max_length=200)



class Medicine(models.Model):
    # 药品名
    name = models.CharField(max_length=200)
    # 药品编号
    sn = models.CharField(max_length=200)
    # 描述
    desc = models.CharField(max_length=200)




class Order(models.Model):
    # 创建日期
    create_date = models.DateField()

    # 客户
    customer = models.ForeignKey(Customer,on_delete=models.PROTECT)

    # 药品
    medicine = models.ForeignKey(Medicine,on_delete=models.PROTECT)

    # 数量
    amount = models.PositiveIntegerField()