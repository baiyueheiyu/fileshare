from django.conf.urls import url
from mgr.sign_in_out import signin, signout
from mgr.customer import dispatcher

urlpatterns = [

    url('signin', signin),
    url('signout', signout),

    url('customers', dispatcher),

]
