from django.http import JsonResponse
from django.db.models import F
from django.db import IntegrityError, transaction

# 导入 Order 对象定义
from  common.models import  Order,OrderMedicine

import json

def dispatcher(request):
    # 将请求参数统一放入request 的 params 属性中，方便后续处理
    if request.method == 'GET':
        request.params = request.GET
        return  listorders(request)

    elif request.method in ['POST','PUT','DELETE']:
        request.params = json.loads(request.body)
        # 根据不同的action分派给不同的函数进行处理
        if request.params['action'] == 'add_order':
            return addorder(request)
        if request.params['action'] == 'modify_order':
            return modifyorder(request)
        elif request.params['action'] == 'del_order':
            return deleteorder(request)

    else:
        return JsonResponse({'ret': 1, 'msg': '不支持该类型http请求'})

def listorders(request):
    # 返回一个 QuerySet 对象 ，包含所有的表记录
    qs = Order.objects.select_related('customer').prefetch_related('medicines')\
            .annotate(
                customer_name=F('customer__name'),
                medicines_name=F('medicines__name')
            )\
            .values(
                'id','name','create_date','customer_name','medicines_name'
            )

    # 将 QuerySet 对象 转化为 list 类型
    # 否则不能 被 转化为 JSON 字符串
    retlist = list(qs)

    # 可能有 ID相同，药品不同的订单记录， 需要合并
    newlist = []
    id2order = {}
    for one in retlist:
        orderid = one['id']         
        if orderid not in id2order:
            newlist.append(one)
            id2order[orderid] = one
        else:
            id2order[orderid]['medicines_name'] += ' | ' + one['medicines_name']

    

    return JsonResponse({'ret': 0, 'retlist': newlist})


def addorder(request):

    info    = request.params['data']

    # 从请求消息中 获取要添加订单的信息
    # 并且插入到数据库中

    
    with transaction.atomic():
        new_order = Order.objects.create(name=info['name'] ,
                                         customer_id=info['customerid'])

        batch = [OrderMedicine(order_id=new_order.id,medicine_id=mid,amount=1)  for mid in info['medicineids']]
        OrderMedicine.objects.bulk_create(batch)


    return JsonResponse({'ret': 0,'id':new_order.id})

def modifyorder(request):

    # 从请求消息中 获取修改客户的信息
    # 找到该客户，并且进行修改操作

    orderid = request.params['id']
    newdata    = request.params['newdata']

    try:
        # 根据 id 从数据库中找到相应的客户记录
        order = Order.objects.get(id=orderid)
    except Order.DoesNotExist:
        return  {
                'ret': 1,
                'msg': f'id 为`{orderid}`的药品不存在'
        }


    if 'name' in  newdata:
        order.name = newdata['name']
    if 'sn' in  newdata:
        order.sn = newdata['sn']
    if 'desc' in  newdata:
        order.desc = newdata['desc']

    # 注意，一定要执行save才能将修改信息保存到数据库
    order.save()

    return JsonResponse({'ret': 0})





def deleteorder(request):

    orderid = request.params['id']

    try:
        # 根据 id 从数据库中找到相应的客户记录
        order = Order.objects.get(id=orderid)
    except Order.DoesNotExist:
        return  {
                'ret': 1,
                'msg': f'id 为`{orderid}`的客户不存在'
        }

    # delete 方法就将该记录从数据库中删除了
    order.delete()

    return JsonResponse({'ret': 0})