from django.conf.urls import url
from mgr.sign_in_out import signin, signout
from mgr import customer,medicine,order

urlpatterns = [

    url('signin', signin),
    url('signout', signout),

    url('customers', customer.dispatcher),
    url('medicines', medicine.dispatcher),
    url('orders', order.dispatcher),

]
