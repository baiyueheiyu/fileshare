import  requests,pprint

payload = {
    'username': 'byhy',
    'password': 'byhybyhy'
}


response = requests.post('http://localhost/api/mgr/signin',
              data=payload)

pprint.pprint(response.json())
